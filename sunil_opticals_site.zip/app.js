const products = [
  {name: "TR90 Frame", price: "₹750"},
  {name: "Stylish Supra Frame", price: "₹1500"},
  {name: "Blue Cut Lens", price: "₹999"},
];

const root = document.getElementById('root');
root.innerHTML = `
<header><h1>Sunil Opticals</h1><p>Quality Frames & Lenses</p></header>
<section class='products'>
${products.map(p => `<div class='card'><h3>${p.name}</h3><p>${p.price}</p></div>`).join('')}
</section>
`;
